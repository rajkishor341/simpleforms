<?php
/**
 * PHPMailer autoloader.
 */

namespace PHPMailer\PHPMailer;

require 'PHPMailer.php';
require 'SMTP.php';
require 'Exception.php';